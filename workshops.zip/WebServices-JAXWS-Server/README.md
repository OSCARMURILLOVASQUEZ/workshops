##Calculator - JAX WS  Web Service Implementation.
Small implementation of JAX Web Services usging a Calculator Example